export default function About() {
  return (
    <section id="about" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h3 className="text-3xl md:text-4xl font-bold text-primary-green mb-8">About Spotless Scapes</h3>
          <p className="text-lg md:text-xl text-gray-700 leading-relaxed">
            Looking for a business you can trust and that is affordable for your lawn care and exterior cleaning? 
            Spotless Scapes is now taking new clients! We are a father and son duo born and raised in Sussex County.
          </p>
          <div className="grid md:grid-cols-3 gap-8 mt-12">
            <div className="text-center">
              <div className="bg-muted p-6 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                <i className="fas fa-users text-2xl text-primary-green"></i>
              </div>
              <h4 className="font-semibold text-lg mb-2">Family Owned</h4>
              <p className="text-gray-600">Father & son team with local roots</p>
            </div>
            <div className="text-center">
              <div className="bg-muted p-6 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                <i className="fas fa-map-marker-alt text-2xl text-primary-green"></i>
              </div>
              <h4 className="font-semibold text-lg mb-2">Local Experts</h4>
              <p className="text-gray-600">Born and raised in Sussex County</p>
            </div>
            <div className="text-center">
              <div className="bg-muted p-6 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                <i className="fas fa-star text-2xl text-primary-green"></i>
              </div>
              <h4 className="font-semibold text-lg mb-2">Quality Service</h4>
              <p className="text-gray-600">Professional results every time</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
