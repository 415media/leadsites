export default function Services() {
  return (
    <section id="services" className="py-16 bg-muted">
      <div className="container mx-auto px-4">
        <h3 className="text-3xl md:text-4xl font-bold text-primary-green text-center mb-12">Our Services</h3>
        
        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Lawn Care Services */}
          <div className="bg-white rounded-xl shadow-lg p-8">
            <div className="text-center mb-8">
              <div className="bg-secondary-green p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <i className="fas fa-seedling text-2xl text-white"></i>
              </div>
              <h4 className="text-2xl font-bold text-primary-green mb-2">Lawn Care Services</h4>
              <p className="text-gray-600">Complete lawn maintenance and care</p>
            </div>
            
            <ul className="space-y-4">
              <li className="flex items-center space-x-3">
                <i className="fas fa-check-circle text-secondary-green"></i>
                <span>Lawn mowing</span>
              </li>
              <li className="flex items-center space-x-3">
                <i className="fas fa-check-circle text-secondary-green"></i>
                <span>Edging & trimming</span>
              </li>
              <li className="flex items-center space-x-3">
                <i className="fas fa-check-circle text-secondary-green"></i>
                <span>Mulching & flowerbed care</span>
              </li>
              <li className="flex items-center space-x-3">
                <i className="fas fa-check-circle text-secondary-green"></i>
                <span>Seasonal cleanups</span>
              </li>
              <li className="flex items-center space-x-3">
                <i className="fas fa-check-circle text-secondary-green"></i>
                <span>Custom lawn care packages</span>
              </li>
            </ul>
          </div>

          {/* Pressure & Soft Washing Services */}
          <div className="bg-white rounded-xl shadow-lg p-8">
            <div className="text-center mb-8">
              <div className="bg-accent-blue p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <i className="fas fa-spray-can text-2xl text-white"></i>
              </div>
              <h4 className="text-2xl font-bold text-primary-green mb-2">Pressure & Soft Washing</h4>
              <p className="text-gray-600">Professional exterior cleaning services</p>
            </div>
            
            <ul className="space-y-4">
              <li className="flex items-center space-x-3">
                <i className="fas fa-check-circle text-accent-blue"></i>
                <span>House washing (soft wash)</span>
              </li>
              <li className="flex items-center space-x-3">
                <i className="fas fa-check-circle text-accent-blue"></i>
                <span>Roof cleaning (soft wash)</span>
              </li>
              <li className="flex items-center space-x-3">
                <i className="fas fa-check-circle text-accent-blue"></i>
                <span>Driveway & sidewalk pressure washing</span>
              </li>
              <li className="flex items-center space-x-3">
                <i className="fas fa-check-circle text-accent-blue"></i>
                <span>Deck & patio washing</span>
              </li>
              <li className="flex items-center space-x-3">
                <i className="fas fa-check-circle text-accent-blue"></i>
                <span>Fence cleaning (wood or vinyl)</span>
              </li>
            </ul>
          </div>
        </div>
        
        {/* Service Note */}
        <div className="max-w-4xl mx-auto mt-8 bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded-r-lg">
          <div className="flex items-start">
            <i className="fas fa-info-circle text-yellow-600 mt-1 mr-3"></i>
            <div>
              <h5 className="font-semibold text-yellow-800 mb-2">Soft Wash vs. Pressure Washing</h5>
              <p className="text-yellow-700 text-sm">
                We use soft washing for delicate surfaces like roofs and siding to prevent damage, 
                while pressure washing is perfect for driveways, sidewalks, and other hard surfaces.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
