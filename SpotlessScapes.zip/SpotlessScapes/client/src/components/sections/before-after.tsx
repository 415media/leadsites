export default function BeforeAfter() {
  // Placeholder data structure for before/after images
  // In a real implementation, these would come from your actual project photos
  const beforeAfterProjects = [
    {
      id: 1,
      title: "Lawn Restoration & Maintenance",
      description: "Complete lawn transformation with regular mowing, edging, and care",
      beforeImage: "/api/placeholder/400/300", // Placeholder - replace with actual before images
      afterImage: "/api/placeholder/400/300",  // Placeholder - replace with actual after images
      service: "Lawn Care"
    },
    {
      id: 2,
      title: "House Soft Washing",
      description: "Professional soft wash cleaning restored this home's exterior",
      beforeImage: "/api/placeholder/400/300",
      afterImage: "/api/placeholder/400/300",
      service: "Soft Washing"
    },
    {
      id: 3,
      title: "Driveway Pressure Washing",
      description: "Pressure washing removed years of dirt and stains",
      beforeImage: "/api/placeholder/400/300",
      afterImage: "/api/placeholder/400/300",
      service: "Pressure Washing"
    }
  ];

  return (
    <section id="before-after" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h3 className="text-3xl md:text-4xl font-bold text-primary-green mb-4">
            See the Spotless Difference
          </h3>
          <p className="text-lg text-gray-700 max-w-2xl mx-auto">
            Our professional lawn care and cleaning services deliver remarkable transformations. 
            See the quality results we provide for our Sussex County neighbors.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {beforeAfterProjects.map((project) => (
            <div key={project.id} className="bg-muted rounded-xl shadow-lg overflow-hidden">
              {/* Before/After Images */}
              <div className="relative">
                <div className="grid grid-cols-2 h-48">
                  {/* Before Image */}
                  <div className="relative bg-gray-300 flex items-center justify-center">
                    <div className="text-center">
                      <i className="fas fa-image text-4xl text-gray-500 mb-2"></i>
                      <p className="text-sm text-gray-600 font-medium">BEFORE</p>
                      <p className="text-xs text-gray-500 mt-1">Photo needed</p>
                    </div>
                    <div className="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded text-xs font-bold">
                      BEFORE
                    </div>
                  </div>
                  
                  {/* After Image */}
                  <div className="relative bg-gray-200 flex items-center justify-center">
                    <div className="text-center">
                      <i className="fas fa-image text-4xl text-gray-500 mb-2"></i>
                      <p className="text-sm text-gray-600 font-medium">AFTER</p>
                      <p className="text-xs text-gray-500 mt-1">Photo needed</p>
                    </div>
                    <div className="absolute top-2 right-2 bg-green-500 text-white px-2 py-1 rounded text-xs font-bold">
                      AFTER
                    </div>
                  </div>
                </div>
              </div>

              {/* Project Details */}
              <div className="p-6">
                <div className="mb-3">
                  <span className="inline-block bg-primary-green text-white px-3 py-1 rounded-full text-xs font-medium">
                    {project.service}
                  </span>
                </div>
                <h4 className="font-bold text-lg text-primary-green mb-2">
                  {project.title}
                </h4>
                <p className="text-gray-600 text-sm">
                  {project.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-12">
          <div className="bg-secondary-green text-white rounded-xl p-8 max-w-4xl mx-auto">
            <h4 className="text-2xl font-bold mb-4">Ready for Your Own Transformation?</h4>
            <p className="text-lg mb-6 opacity-90">
              Let us show you what professional lawn care and exterior cleaning can do for your property.
            </p>
            <button 
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-accent-blue hover:bg-blue-600 text-white font-bold py-3 px-8 rounded-lg text-lg transition-all duration-300 transform hover:scale-105"
            >
              Get Your Free Estimate Today
            </button>
          </div>
        </div>

        {/* Note for adding real photos */}
        <div className="mt-8 max-w-4xl mx-auto bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded-r-lg">
          <div className="flex items-start">
            <i className="fas fa-camera text-yellow-600 mt-1 mr-3"></i>
            <div>
              <h5 className="font-semibold text-yellow-800 mb-2">Add Your Project Photos</h5>
              <p className="text-yellow-700 text-sm">
                This section is ready for your actual before and after photos! Upload your best transformation 
                images to showcase the quality of Spotless Scapes' work and attract new customers.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}