import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

export default function Contact() {

  return (
    <section id="contact" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h3 className="text-3xl md:text-4xl font-bold text-primary-green text-center mb-12">Request Your Free Estimate</h3>
        
        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Contact Form */}
          <div className="bg-muted rounded-xl p-8">
            <form 
              name="contact"
              method="POST"
              data-netlify="true"
              data-netlify-honeypot="bot-field"
              action="/thank-you"
              className="space-y-6"
            >
              {/* Netlify Forms Configuration */}
              <input type="hidden" name="form-name" value="contact" />
              <div style={{ display: 'none' }}>
                <label>
                  Don't fill this out if you're human: <input name="bot-field" />
                </label>
              </div>
              
              <div>
                <Label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                  Name *
                </Label>
                <Input
                  id="name"
                  name="name"
                  required
                  className="w-full"
                  placeholder="Your full name"
                />
              </div>
              
              <div>
                <Label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                  Phone *
                </Label>
                <Input
                  id="phone"
                  name="phone"
                  type="tel"
                  required
                  className="w-full"
                  placeholder="Your phone number"
                />
              </div>
              
              <div>
                <Label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                  Email *
                </Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  required
                  className="w-full"
                  placeholder="Your email address"
                />
              </div>
              
              <div>
                <Label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                  Message
                </Label>
                <Textarea
                  id="message"
                  name="message"
                  rows={4}
                  className="w-full"
                  placeholder="Tell us about your project (lawn care, pressure washing, etc.)..."
                />
              </div>
              
              <Button
                type="submit"
                className="w-full bg-primary-green hover:bg-secondary-green text-white font-bold py-3 px-6 rounded-lg transition-colors duration-300"
              >
                Send Message
              </Button>
            </form>
          </div>
          
          {/* Contact Information */}
          <div className="space-y-8">
            <div>
              <h4 className="text-2xl font-bold text-primary-green mb-6">Get In Touch</h4>
              <p className="text-gray-700 mb-6">
                Ready to transform your outdoor space? Contact us today for your free estimate!
              </p>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <div className="bg-primary-green p-3 rounded-full">
                  <i className="fas fa-phone text-white"></i>
                </div>
                <div>
                  <p className="font-semibold">Phone</p>
                  <a href="tel:302-855-8594" className="text-primary-green hover:text-secondary-green transition-colors">
                    (302) 855-8594
                  </a>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="bg-primary-green p-3 rounded-full">
                  <i className="fas fa-envelope text-white"></i>
                </div>
                <div>
                  <p className="font-semibold">Email</p>
                  <a href="mailto:askspotless@gmail.com" className="text-primary-green hover:text-secondary-green transition-colors">
                    askspotless@gmail.com
                  </a>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="bg-primary-green p-3 rounded-full">
                  <i className="fas fa-clock text-white"></i>
                </div>
                <div>
                  <p className="font-semibold">Hours</p>
                  <p className="text-gray-700">Mon–Sat, 8AM–6PM</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="bg-primary-green p-3 rounded-full">
                  <i className="fas fa-map-marker-alt text-white"></i>
                </div>
                <div>
                  <p className="font-semibold">Service Area</p>
                  <p className="text-gray-700">Sussex County, Delaware</p>
                </div>
              </div>
            </div>
            
            {/* Social Links */}
            <div className="pt-6">
              <h5 className="font-semibold mb-4">Follow Us</h5>
              <div className="flex space-x-4">
                <a 
                  href="https://www.facebook.com/people/Spotless-Scapes/61564857107312" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-accent-blue hover:bg-blue-600 text-white p-3 rounded-full transition-colors duration-300"
                >
                  <i className="fab fa-facebook-f"></i>
                </a>
                <a 
                  href="https://www.google.com/maps/place/Spotless+Scapes/@38.570041,-75.5885784,11z" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-red-500 hover:bg-red-600 text-white p-3 rounded-full transition-colors duration-300"
                >
                  <i className="fab fa-google"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
