export default function Testimonials() {
  const testimonials = [
    {
      name: "Sarah Johnson",
      location: "Rehoboth Beach, DE",
      quote: "Spotless Scapes transformed our yard! The father and son team was professional, punctual, and did an amazing job with our lawn mowing and mulching. Highly recommend them to anyone in Sussex County!"
    },
    {
      name: "Mike Thompson",
      location: "Millsboro, DE",
      quote: "Their soft washing service made our house look brand new! Very affordable pricing and they explained everything before starting. Great local business that truly cares about their customers."
    }
  ];

  return (
    <section id="testimonials" className="py-16 bg-muted">
      <div className="container mx-auto px-4">
        <h3 className="text-3xl md:text-4xl font-bold text-primary-green text-center mb-12">What Our Customers Say</h3>
        
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg p-8">
              <div className="flex items-start mb-4">
                <div className="text-4xl text-secondary-green mr-4">"</div>
                <div>
                  <p className="text-gray-700 mb-4 italic">
                    {testimonial.quote}
                  </p>
                  <div className="flex items-center">
                    <div>
                      <p className="font-semibold text-primary-green">{testimonial.name}</p>
                      <p className="text-sm text-gray-500">{testimonial.location}</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex text-yellow-400">
                {[...Array(5)].map((_, i) => (
                  <i key={i} className="fas fa-star"></i>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
