export default function WhyChooseUs() {
  const features = [
    {
      icon: "fas fa-home",
      title: "Local, Family-Owned",
      description: "Supporting our Sussex County community"
    },
    {
      icon: "fas fa-dollar-sign",
      title: "Affordable, Upfront Pricing",
      description: "No hidden fees or surprise charges"
    },
    {
      icon: "fas fa-tools",
      title: "Professional Equipment",
      description: "Modern tools for quality results"
    },
    {
      icon: "fas fa-clock",
      title: "Reliable & Punctual",
      description: "We show up when we say we will"
    },
    {
      icon: "fas fa-shield-alt",
      title: "100% Satisfaction Guaranteed",
      description: "Your happiness is our priority"
    },
    {
      icon: "fas fa-heart",
      title: "Proudly Serving Neighbors",
      description: "Sussex County is our home too"
    }
  ];

  return (
    <section id="why-choose-us" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h3 className="text-3xl md:text-4xl font-bold text-primary-green text-center mb-12">Why Choose Spotless Scapes?</h3>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {features.map((feature, index) => (
            <div key={index} className="text-center">
              <div className="bg-muted p-6 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                <i className={`${feature.icon} text-2xl text-primary-green`}></i>
              </div>
              <h4 className="font-semibold text-lg mb-2">{feature.title}</h4>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
