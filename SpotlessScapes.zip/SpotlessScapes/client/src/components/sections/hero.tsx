import lawnBackgroundImage from "@assets/Spotless Scapes Lawn Care.png";

export default function Hero() {
  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ 
      behavior: 'smooth' 
    });
  };

  return (
    <section 
      id="hero"
      className="relative text-white py-20 overflow-hidden"
      style={{
        backgroundImage: `linear-gradient(135deg, rgba(45, 90, 39, 0.75) 0%, rgba(74, 124, 89, 0.7) 100%), url("${lawnBackgroundImage}")`,
        backgroundSize: 'cover',
        backgroundPosition: 'center center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      <div className="container mx-auto px-4 text-center relative z-10">
        <h2 className="text-4xl md:text-6xl font-bold mb-6 drop-shadow-lg">
          Professional Lawn Care &<br />Exterior Cleaning
        </h2>
        <p className="text-xl md:text-2xl mb-8 opacity-95 drop-shadow-md">
          A father & son duo proudly serving Sussex County, Delaware.
        </p>
        <button 
          onClick={scrollToContact}
          className="bg-accent-blue hover:bg-blue-600 text-white font-bold py-4 px-8 rounded-lg text-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
        >
          Get Your Free Estimate
        </button>
      </div>
    </section>
  );
}
