import { useState } from "react";
import spotlessScapesLogo from "@assets/Spotless Scapes Logo (1).png";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      // Get actual header height dynamically
      const header = document.querySelector('header');
      const headerHeight = header ? header.offsetHeight + 20 : 120; // Add extra padding
      const elementPosition = element.getBoundingClientRect().top + window.pageYOffset;
      const offsetPosition = elementPosition - headerHeight;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
    setIsMobileMenuOpen(false);
  };

  const navigationItems = [
    { name: 'About', id: 'about' },
    { name: 'Services', id: 'services' },
    { name: 'Gallery', id: 'before-after' },
    { name: 'Why Choose Us', id: 'why-choose-us' },
    { name: 'Reviews', id: 'testimonials' },
    { name: 'Contact', id: 'contact' }
  ];

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <img 
              src={spotlessScapesLogo} 
              alt="Spotless Scapes Logo" 
              className="h-12 w-auto"
            />
            <div>
              <h1 className="text-xl font-bold text-primary-green">Spotless Scapes</h1>
              <p className="text-sm text-secondary-green font-medium">Reliable. Affordable. Local.</p>
            </div>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-6">
            {navigationItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className="text-gray-700 hover:text-primary-green font-medium transition-colors duration-300"
              >
                {item.name}
              </button>
            ))}
          </nav>
          
          {/* Desktop CTA Buttons */}
          <div className="hidden lg:flex items-center space-x-4">
            <a 
              href="tel:302-855-8594" 
              className="flex items-center space-x-2 bg-primary-green hover:bg-secondary-green text-white px-4 py-2 rounded-lg font-medium transition-colors duration-300"
            >
              <i className="fas fa-phone"></i>
              <span>Call Now</span>
            </a>
            <button 
              onClick={() => scrollToSection('contact')}
              className="bg-accent-blue hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-medium transition-colors duration-300"
            >
              Free Quote
            </button>
          </div>
          
          {/* Mobile Menu Button */}
          <button 
            className="lg:hidden text-primary-green p-2"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            <i className={`fas ${isMobileMenuOpen ? 'fa-times' : 'fa-bars'} text-xl`}></i>
          </button>
        </div>
        
        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden mt-4 pb-4 border-t bg-white">
            <nav className="flex flex-col space-y-4 pt-4">
              {navigationItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className="text-left text-gray-700 hover:text-primary-green font-medium transition-colors duration-300 py-2"
                >
                  {item.name}
                </button>
              ))}
              
              {/* Mobile CTA Buttons */}
              <div className="flex flex-col space-y-3 pt-4 border-t">
                <a 
                  href="tel:302-855-8594" 
                  className="flex items-center justify-center space-x-2 bg-primary-green hover:bg-secondary-green text-white py-3 rounded-lg font-bold transition-colors duration-300"
                >
                  <i className="fas fa-phone"></i>
                  <span>(302) 855-8594</span>
                </a>
                <button 
                  onClick={() => scrollToSection('contact')}
                  className="bg-accent-blue hover:bg-blue-600 text-white py-3 rounded-lg font-bold transition-colors duration-300"
                >
                  Get Your Free Estimate
                </button>
                
                {/* Contact Info */}
                <div className="flex flex-col space-y-2 pt-3 border-t text-sm">
                  <a href="mailto:askspotless@gmail.com" className="flex items-center space-x-2 text-gray-600 hover:text-primary-green transition-colors">
                    <i className="fas fa-envelope"></i>
                    <span>askspotless@gmail.com</span>
                  </a>
                  <div className="flex items-center space-x-2 text-gray-600">
                    <i className="fas fa-clock"></i>
                    <span>Mon–Sat, 8AM–6PM</span>
                  </div>
                </div>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
