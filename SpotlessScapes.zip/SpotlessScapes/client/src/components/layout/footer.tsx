import spotlessScapesLogo from "@assets/Spotless Scapes Logo (1).png";

export default function Footer() {
  return (
    <footer className="bg-primary-green text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Logo and Info */}
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <img 
                src={spotlessScapesLogo} 
                alt="Spotless Scapes Logo" 
                className="h-10 w-auto"
              />
              <div>
                <h4 className="text-lg font-bold">Spotless Scapes</h4>
                <p className="text-sm opacity-80">Reliable. Affordable. Local.</p>
              </div>
            </div>
            <p className="text-sm opacity-80">
              Professional lawn care and exterior cleaning services 
              proudly serving Sussex County, Delaware.
            </p>
          </div>
          
          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">Services</h4>
            <ul className="space-y-2 text-sm opacity-80">
              <li>• Lawn Mowing & Maintenance</li>
              <li>• House & Roof Washing</li>
              <li>• Pressure Washing</li>
              <li>• Seasonal Cleanup</li>
              <li>• Mulching & Landscaping</li>
            </ul>
          </div>
          
          {/* Contact Info */}
          <div>
            <h4 className="font-semibold mb-4">Contact Us</h4>
            <div className="space-y-2 text-sm opacity-80">
              <p>
                <i className="fas fa-phone mr-2"></i>
                <a href="tel:302-855-8594" className="hover:text-accent-blue transition-colors">
                  (302) 855-8594
                </a>
              </p>
              <p>
                <i className="fas fa-envelope mr-2"></i>
                <a href="mailto:askspotless@gmail.com" className="hover:text-accent-blue transition-colors">
                  askspotless@gmail.com
                </a>
              </p>
              <p><i className="fas fa-clock mr-2"></i>Mon–Sat, 8AM–6PM</p>
              <p><i className="fas fa-map-marker-alt mr-2"></i>Sussex County, DE</p>
            </div>
            
            <div className="flex space-x-3 mt-4">
              <a 
                href="https://www.facebook.com/people/Spotless-Scapes/61564857107312" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-white hover:text-accent-blue transition-colors duration-300"
              >
                <i className="fab fa-facebook-f text-lg"></i>
              </a>
              <a 
                href="https://www.google.com/maps/place/Spotless+Scapes/@38.570041,-75.5885784,11z" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-white hover:text-red-400 transition-colors duration-300"
              >
                <i className="fab fa-google text-lg"></i>
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-secondary-green mt-8 pt-8 text-center">
          <p className="text-sm opacity-80">© 2025 Spotless Scapes. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
